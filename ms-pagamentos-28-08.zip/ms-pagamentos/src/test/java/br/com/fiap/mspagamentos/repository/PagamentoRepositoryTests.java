package br.com.fiap.mspagamentos.repository;

import br.com.fiap.mspagamentos.model.Pagamento;
import br.com.fiap.mspagamentos.utils.ObjectsFactory;
import org.junit.jupiter.api.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.dao.EmptyResultDataAccessException;

import javax.persistence.EntityNotFoundException;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;

@DataJpaTest
class PagamentoRepositoryTests {

    @Autowired
    private PagamentoRepository repository;

    private Long existingID;
    private Long notExistingID;
    private Long countTotalPagamento;


    @BeforeEach
    void setup() throws Exception {
        existingID = 1L;
        notExistingID = 100L;
        countTotalPagamento = 2L;
    }

    @Test
    @DisplayName("Deveria excluir pagamento quando o ID existir")
    public void deletaObjetoSeEleExiste(){
        repository.deleteById(existingID);
        Optional<Pagamento> result = repository.findById(existingID);
        Assertions.assertFalse(result.isPresent());
    }

    @Test
    @DisplayName("Deveria dar uma exception ao tentar excluir pagamento que não existe")
    public void tentaDeletarObjetoQueNaoExiste(){
        Assertions.assertThrows(EmptyResultDataAccessException.class, () -> repository.deleteById(notExistingID));
    }

    @Test
    @DisplayName("Save deveria salvar objeto com auto incremento quando o ID é null")
    public void saveDeveriaSalvarObjetoComAutoIncrementoQuandoIDehNull(){
        Pagamento pagamento = ObjectsFactory.createPagamento();
        pagamento.setId(null);
        pagamento = repository.save(pagamento);
        Assertions.assertNotNull(pagamento.getId());

        Assertions.assertEquals(countTotalPagamento+1, pagamento.getId());
    }

    @Test
    @DisplayName("FindById deveria retornar um Optional<Pagamento> não vazio quando o id existir")
    public void findByIdDeveriaRetornarUmOptionalPagamento(){
        Optional<Pagamento> pagamento = repository.findById(existingID);

        Assertions.assertNotNull(pagamento.get());
        Assertions.assertEquals(Optional.class, pagamento.getClass());
    }

    @Test
    @DisplayName("FindById deveria retornar um Optional<Pagamento> vazio quando o id não existir")
    public void findByIdDeveriaRetornarUmOptionalPagamentoVazio(){
        Optional<Pagamento> pagamento = repository.findById(notExistingID);

        Assertions.assertEquals(false, pagamento.isPresent());
        Assertions.assertEquals(Optional.class, pagamento.getClass());
    }

}