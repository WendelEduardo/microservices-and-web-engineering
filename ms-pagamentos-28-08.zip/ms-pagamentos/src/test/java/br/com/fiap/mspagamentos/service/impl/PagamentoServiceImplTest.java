package br.com.fiap.mspagamentos.service.impl;

import br.com.fiap.mspagamentos.model.Pagamento;
import br.com.fiap.mspagamentos.repository.PagamentoRepository;
import br.com.fiap.mspagamentos.utils.ObjectsFactory;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import javax.persistence.EntityNotFoundException;
import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

@ExtendWith(SpringExtension.class)
class PagamentoServiceImplTest {

    @InjectMocks
    private PagamentoServiceImpl pagamentoService;

    @Mock
    private PagamentoRepository repository;

    private Long existingID;
    private Long notExistingID;
    private Long countTotalPagamento;


    @BeforeEach
    void setup() throws Exception {
        existingID = 1L;
        notExistingID = 100L;
        countTotalPagamento = 2L;

        Mockito.doNothing().when(repository).deleteById(existingID);
        Mockito.when(repository.existsById(existingID)).thenReturn(true);
        Mockito.when(repository.existsById(notExistingID)).thenReturn(false);
    }

    @Test
    void returnListOfPayments() {
        Mockito.when(repository.findAll()).thenReturn(ObjectsFactory.createListOfPagamentos());

        Assertions.assertEquals(ArrayList.class, pagamentoService.returnListOfPayments().getClass());
        Assertions.assertEquals(3, pagamentoService.returnListOfPayments().size());
    }

    @Test
    void findPaymentByID() {
    }

    @Test
    void postPayment() {
    }

    @Test
    @DisplayName("Delete deveria não fazer nada quando ID existe")
    void deletePaymentByID() {
        Assertions.assertDoesNotThrow(() -> {
            pagamentoService.deletePaymentByID(existingID);
        });

        Mockito.verify(repository, Mockito.times(1)).deleteById(existingID);
    }

    @Test
    @DisplayName("Teste delete lança ResourceNotFoundException quando ID não existe")
    void testeDeleteLancaResourceNotFoundException() {
        Assertions.assertThrows(EntityNotFoundException.class, () -> pagamentoService.deletePaymentByID(notExistingID));
    }

    @Test
    void editPayment() {
    }

    @Test
    void confirmarPedido() {
    }

    @Test
    void cancelarPedido() {
    }
}