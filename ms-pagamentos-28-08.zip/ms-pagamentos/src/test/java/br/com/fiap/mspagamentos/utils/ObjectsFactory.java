package br.com.fiap.mspagamentos.utils;

import br.com.fiap.mspagamentos.model.Pagamento;
import br.com.fiap.mspagamentos.model.Status;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

public class ObjectsFactory {

    public static Pagamento createPagamento(){
        return new Pagamento(1L, BigDecimal.valueOf(32.35), "Bach",
                "4324324", "07/25", "547", Status.CRIADO, 1L, 2L);
    }

    public static List<Pagamento> createListOfPagamentos(){
        List<Pagamento> pagamentoList = new ArrayList<>();
        pagamentoList.add(ObjectsFactory.createPagamento());
        pagamentoList.add(ObjectsFactory.createPagamento());
        pagamentoList.add(ObjectsFactory.createPagamento());

        return pagamentoList;
    }

}
