package br.com.fiap.mspagamentos.exception;

import java.time.Instant;

public class ApplicationException extends RuntimeException{

    private Instant timestamp;
    private Integer status;
    private String error;
    private String message;
    private String path;

    public ApplicationException(Instant timestamp, Integer status, String error, String message, String path) {
        this.timestamp = timestamp;
        this.status = status;
        this.error = error;
        this.message = message;
        this.path = path;
    }

    public ApplicationException() {
    }


}
