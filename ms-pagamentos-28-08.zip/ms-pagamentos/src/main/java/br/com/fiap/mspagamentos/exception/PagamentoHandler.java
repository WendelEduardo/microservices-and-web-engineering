package br.com.fiap.mspagamentos.exception;

import br.com.fiap.mspagamentos.model.Status;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import javax.persistence.EntityNotFoundException;
import javax.servlet.http.HttpServletRequest;
import javax.validation.Validation;
import java.time.Instant;

@RestControllerAdvice
public class PagamentoHandler extends ResponseEntityExceptionHandler {

    Logger logger = LoggerFactory.getLogger(PagamentoHandler.class);

    @ResponseStatus(value = HttpStatus.NOT_FOUND, reason = "Não há registros no banco.")
    @ExceptionHandler(value = NullPointerException.class)
    public ApplicationException semRegistroNoBanco(Exception e){
        logger.info("Não há mais registros no banco.");

        return new ApplicationException(Instant.now(), HttpStatus.NOT_FOUND.value(),
                "Não há mais registros no banco.", e.getMessage(), e.getLocalizedMessage());
    }

    @ResponseStatus(value = HttpStatus.NOT_FOUND, reason = "Objeto não encontrado.")
    @ExceptionHandler(value = EntityNotFoundException.class)
    public ResponseEntity objetoNaoEncontrado(Exception e){
        logger.info("Objeto não encontrado.");
        return ResponseEntity.notFound().build();
    }

//    @ResponseStatus(value = HttpStatus.UNPROCESSABLE_ENTITY, reason = "Objeto não encontrado.")
////    @ExceptionHandler(value = MethodArgumentNotValidException.class)
//    public ResponseEntity<ValidationCustomErrorDTO> objetoNaoEncontrado(MethodArgumentNotValidException e , HttpServletRequest request){
//        logger.info("Objeto não encontrado.");
//
//        HttpStatus status = HttpStatus.UNPROCESSABLE_ENTITY;
//
//        ValidationCustomErrorDTO errorDTO = new ValidationCustomErrorDTO(Instant.now(), status.value(),
//                "Dados inválidos", request.getRequestURI(), e.getLocalizedMessage());
//
//        for (FieldError fieldError : e.getBindingResult().getFieldErrors()){
//            errorDTO.addError(fieldError.getField(), fieldError.getDefaultMessage());
//        }
//
//        return ResponseEntity.status(status).body(errorDTO);
//    }


}
