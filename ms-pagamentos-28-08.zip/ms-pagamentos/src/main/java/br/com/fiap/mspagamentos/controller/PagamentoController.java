package br.com.fiap.mspagamentos.controller;

import br.com.fiap.mspagamentos.dto.PagamentoDTO;
import br.com.fiap.mspagamentos.model.Pagamento;
import br.com.fiap.mspagamentos.service.impl.PagamentoServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import javax.validation.Valid;
import javax.validation.constraints.Positive;
import java.net.URI;
import java.util.List;

@RestController
@RequestMapping("/pagamentos")
public class PagamentoController {

	@Autowired
	private PagamentoServiceImpl service;
	
	@GetMapping
	public ResponseEntity<List<PagamentoDTO>> getListOfPayments() {
		return ResponseEntity.ok().body(service.returnListOfPayments());
	}

	@GetMapping("/{id}")
	public ResponseEntity<PagamentoDTO> findPaymentsByID(@PathVariable("id") Long id){
		return ResponseEntity.ok().body(service.findPaymentByID(id));
	}

	@PostMapping
	public ResponseEntity<PagamentoDTO> postPayment(@RequestBody @Valid PagamentoDTO pagamentoDTO){
		PagamentoDTO dto = service.postPayment(pagamentoDTO);

		URI uri = ServletUriComponentsBuilder.fromCurrentRequest().path("/{id}").buildAndExpand(dto.getId()).toUri();

		return ResponseEntity.created(uri).body(dto);
	}

	@PutMapping("/{id}")
	public ResponseEntity<PagamentoDTO> editPayment(@PathVariable("id") @Positive Long id,
													@RequestBody @Valid PagamentoDTO pagamentoDTO){
		return ResponseEntity.ok().body(service.editPayment(id, pagamentoDTO));
	}

	@DeleteMapping("/{id}")
	public ResponseEntity<Void> deletePaymentByID(@PathVariable("id") Long id){
		service.deletePaymentByID(id);
		return ResponseEntity.noContent().build();
	}

	@PatchMapping("/{id}/confirmar")
	public ResponseEntity<PagamentoDTO> confirmarPedido(@PathVariable("id") Long id){
		return ResponseEntity.ok().body(service.confirmarPedido(id));
	}

	@PatchMapping("/{id}/cancelar")
	public ResponseEntity<PagamentoDTO> cancelarPedido(@PathVariable("id") Long id){
		return ResponseEntity.ok().body(service.cancelarPedido(id));
	}

}
