package br.com.fiap.mspagamentos.service;

import br.com.fiap.mspagamentos.dto.PagamentoDTO;
import br.com.fiap.mspagamentos.model.Pagamento;

import java.util.List;

public interface PagamentoService {

    List<PagamentoDTO> returnListOfPayments();

    PagamentoDTO findPaymentByID(Long id);

    PagamentoDTO postPayment(PagamentoDTO pagamentoDTO);

    void deletePaymentByID(Long id);

    PagamentoDTO editPayment(Long id, PagamentoDTO pagamentoDTO);

    PagamentoDTO confirmarPedido(Long id);

    PagamentoDTO cancelarPedido(Long id);
}
