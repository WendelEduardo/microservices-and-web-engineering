package br.com.fiap.mspagamentos.service.impl;

import br.com.fiap.mspagamentos.dto.PagamentoDTO;
import br.com.fiap.mspagamentos.model.Pagamento;
import br.com.fiap.mspagamentos.model.Status;
import br.com.fiap.mspagamentos.repository.PagamentoRepository;
import br.com.fiap.mspagamentos.service.PagamentoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.persistence.EntityNotFoundException;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.stream.Collectors;

@Service
public class PagamentoServiceImpl implements PagamentoService {

    @Autowired
    private PagamentoRepository pagamentoRepository;

    @Override
    @Transactional(readOnly = true)
    public List<PagamentoDTO> returnListOfPayments() {
        List<Pagamento> listOfPayments = pagamentoRepository.findAll();

        if(listOfPayments.isEmpty()){
            throw new NullPointerException();
        }

//        List<PagamentoDTO> listOfPaymentsDTO = new ArrayList<PagamentoDTO>();
//        int index = 0;
//
//        listOfPayments.forEach(c -> {
//            listOfPaymentsDTO.add(new PagamentoDTO(c));
//        });

//        return listOfPayments.stream().map(c -> new PagamentoDTO(c)).collect(Collectors.toList());
        return listOfPayments.stream().map(PagamentoDTO::new).collect(Collectors.toList());
    }

    @Override
    @Transactional(readOnly = true)
    public PagamentoDTO findPaymentByID(Long id) {
        Pagamento pagamento = pagamentoRepository.findById(id).orElseThrow(() -> new EntityNotFoundException());
        return new PagamentoDTO(pagamento);
    }

    @Override
    @Transactional
    public PagamentoDTO postPayment(PagamentoDTO pagamentoDTO) {
        Pagamento pagamento = this.copyDtoToEntity(pagamentoDTO);
        pagamento.setStatus(Status.CRIADO);

        pagamento = pagamentoRepository.save(pagamento);

        return new PagamentoDTO(pagamento);
    }

    @Override
    @Transactional
    public void deletePaymentByID(Long id) {
        if(this.findPaymentByID(id) == null){
            new EntityNotFoundException();
        }else{
            pagamentoRepository.deleteById(id);
        }
    }

    @Override
    public PagamentoDTO editPayment(Long id, PagamentoDTO pagamentoDTO) {

        if(this.findPaymentByID(id).equals(null)){
            new EntityNotFoundException();
        }

        pagamentoDTO.setId(id);

        Pagamento pagamento = pagamentoRepository.findById(id).get();
        pagamento = pagamentoRepository.save(this.copyDtoToEntity(pagamentoDTO));

        return new PagamentoDTO(pagamento);
    }

    private Pagamento copyDtoToEntity(PagamentoDTO dto){
        Pagamento pagamento = new Pagamento();
        pagamento.setId(dto.getId());
        pagamento.setValor(dto.getValor());
        pagamento.setNome(dto.getNome());
        pagamento.setCodigo(dto.getCodigo());
        pagamento.setStatus(dto.getStatus());
        pagamento.setPedidoId(dto.getPedidoId());
        pagamento.setValidade(dto.getValidade());
        pagamento.setNumeroDoCartao(dto.getNumeroDoCartao());
        pagamento.setFormaDePagamentoId(dto.getFormaDePagamentoId());

        return pagamento;
    }

}
