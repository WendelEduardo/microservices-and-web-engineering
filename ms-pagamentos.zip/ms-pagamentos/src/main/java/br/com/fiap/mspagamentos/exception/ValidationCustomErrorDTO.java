package br.com.fiap.mspagamentos.exception;

import java.time.Instant;

public class ValidationCustomErrorDTO {
    private Instant timestamp;
    private Integer status;
    private String error;
    private String message;
    private String path;


    public ValidationCustomErrorDTO(Instant timestamp, Integer status, String error, String message, String path) {
        this.timestamp = timestamp;
        this.status = status;
        this.error = error;
        this.message = message;
        this.path = path;
    }

    public ValidationCustomErrorDTO() {
    }



    public void addError(String field, String defaultMessage) {

    }
}
