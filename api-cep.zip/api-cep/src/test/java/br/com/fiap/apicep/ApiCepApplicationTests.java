package br.com.fiap.apicep;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApiCepApplicationTests {

	@Test
	void contextLoads() {
	}

}
