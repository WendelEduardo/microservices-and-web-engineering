package br.com.fiap.apicep.service;

import br.com.fiap.apicep.dto.EnderecoDTO;

public interface EnderecoService {
    EnderecoDTO findCep(String cep);
}
