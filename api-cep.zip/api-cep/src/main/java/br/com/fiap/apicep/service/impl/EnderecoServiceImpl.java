package br.com.fiap.apicep.service.impl;

import br.com.fiap.apicep.dto.EnderecoDTO;
import br.com.fiap.apicep.model.Endereco;
import br.com.fiap.apicep.service.EnderecoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

public class EnderecoServiceImpl implements EnderecoService {

    @Autowired
    private RestTemplate restTemplate;

    @Override
    public EnderecoDTO findCep(String cep) {
        String url = "https://viacep.com.br/ws/08576317/json/";
        ResponseEntity<Endereco> responseEntity = restTemplate.getForEntity(url, Endereco.class);
        Endereco endereco = responseEntity.getBody();

        System.out.println(endereco);

        return new EnderecoDTO(endereco);
    }

}
