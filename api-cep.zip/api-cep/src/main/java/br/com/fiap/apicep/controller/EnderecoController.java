package br.com.fiap.apicep.controller;

import br.com.fiap.apicep.dto.EnderecoDTO;
import br.com.fiap.apicep.service.EnderecoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("api/v1/cep")
public class EnderecoController {

    @Autowired
    private EnderecoService service;

    @GetMapping
    public ResponseEntity<EnderecoDTO> findCep(@RequestParam("cep") String cep) {
        return ResponseEntity.ok().body(service.findCep(cep));
    }

}
