package br.com.fiap.mspagamentos.exception;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import javax.persistence.EntityNotFoundException;

@ControllerAdvice
public class PagamentoHandler extends ResponseEntityExceptionHandler {

    Logger logger = LoggerFactory.getLogger(PagamentoHandler.class);

    @ResponseStatus(value = HttpStatus.NOT_FOUND, reason = "Não há registros no banco.")
    @ExceptionHandler(value = NullPointerException.class)
    public ResponseEntity semRegistroNoBanco(Exception e){
        logger.info("Não há mais registros no banco.");
        return ResponseEntity.notFound().build();
    }

    @ResponseStatus(value = HttpStatus.NOT_FOUND, reason = "Objeto não encontrado.")
    @ExceptionHandler(value = EntityNotFoundException.class)
    public ResponseEntity objetoNaoEncontrado(Exception e){
        logger.info("Objeto não encontrado.");
        return ResponseEntity.notFound().build();
    }

}
